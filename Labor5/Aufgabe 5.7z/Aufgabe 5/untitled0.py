import redlab as rl
print(rl.cbVIn(0,0,1))

