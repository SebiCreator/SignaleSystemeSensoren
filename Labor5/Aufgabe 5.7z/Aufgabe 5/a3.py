import redlab as rl
ad = []
v = 0

rl.cbVOut(0,0,101, v)